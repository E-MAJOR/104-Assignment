console.log('Register page');
let saloon={
    name:"Pets R Us",
    address:{
        street:"University",
        number: "758-K",
        zip: 22560,
        state:"CA",
        city:"San Diego"
    },
    hours:{
        open:"09:00",
        close: "20:00"
    },
    pets:[

    //     {
    //         name:"Scooby",
    //         age:8,
    //         gender:'male',
    //         breed:'Dane',
    //         service:'Grooming',
    //         owner:'Shaggy',
    //         phone:555-555-5555
    //     },
    //     {
    //         name:"Star",
    //         age:10,
    //         gender:'female',
    //         breed:'Collie',
    //         service:'Nails but',
    //         owner:'Shaggy',
    //         phone:777-777-7777
    //     },
    //     {
    //         name:"Smokey",
    //         age:13,
    //         gender:'male',
    //         breed:'Lasha',
    //         service:'Grooming',
    //         owner:'Mark',
    //         phone:888-888-8888
    //     },
    //     {
    //         name:"Drake",
    //         age:5,
    //         gender:'male',
    //         breed:'Bulldog',
    //         service:'Nails but',
    //         owner:'Cindy',
    //         phone:555-555-9999
    //     },
    ]
    //create a pet constructor
    
}
function Pet(name, age, gender, breed, service, ownerName, contactPhone){
    this.name=name;
    this.age=age;
    this.gender=gender;
    this.breed=breed;
    this.service=service;
    this.owner=ownerName;
    this.phone=contactPhone;
}


//get values from input

let txtName=document.getElementById("petName");
let txtAge=document.getElementById("petAge");
let txtGender=document.getElementById("petGender");
let txtBreed=document.getElementById("petBreed");
let txtService=document.getElementById("petService");
let txtOwner=document.getElementById("ownerName");
let txtPhone=document.getElementById("ownerPhone");


               



function register(){
    //create constructor using values from the input

    //push into the array
    //diplay pet on console
    //call clear function
   
    console.log(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value);
    let newPet=new Pet(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value);
    saloon.pets.push(newPet);
    console.log(saloon.pets);
    displayCards(newPet);
    clear();
}
function clear(){
    //to clear the input
    txtAge.value='';
    txtBreed.value='';
    txtGender.value='';
    txtName.value='';
    txtOwner.value=''; 
    txtPhone.value=''; 
    txtService.value='';

    

}

let scooby=new Pet("Scooby",8, "male", "Collie", "Shampoo", "Shaggy", "555-555-5555");

let scrappy=new Pet("Scrappy",47, "male", "Cockatoo", "Nail Trim", "Shaggy", "555-444-4444");

let lady=new Pet("Lady",13, "female", "Bengal", "Daycare", "Enna", "777-777-7777");
console.log(scooby, scrappy, lady);
saloon.pets.push(scooby, scrappy, lady);
console.log("saloon.pets = " + saloon.pets);

displayCards(scooby);
displayCards(scrappy);
displayCards(lady);




// console.log(saloon.address.city);
// console.log(saloon.pets);
// // display in alert the amount of pets
// alert(`${saloon.pets.length} registered pets`);

function simpleDisplay(){
    // iterate through the array
    for(let i = 0; i<saloon.pets.length; i++){
        console.log(`${saloon.pets[i].name}`);
    }

}

simpleDisplay();

// function simpleDisplay2(){
//     let i=0;
//     while(saloon.pets[i]!=undefined){
//         i++;
//         console.log(`${saloon.pets[i].name}`);
//     }
// }
// simpleDisplay2();

